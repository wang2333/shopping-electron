- yarn 安装依赖

### 开发环境

1. npm run dev 启动前端项目
2. npm run electron:dev 启动 electron 项目

### mac 系统打包

1.  npm run build 打包前端项目
2.  npm run package1 打包 electron 项目
3.  npm run dmg 打包为 mac 上的 dmg 文件
