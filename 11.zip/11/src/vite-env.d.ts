declare module 'postcss-px-to-viewport';
declare module '*.png' {
  const value: any;
  export = value;
}
declare module '*.svg' {
  const value: any;
  export = value;
}
/// <reference types="vite/client" />
